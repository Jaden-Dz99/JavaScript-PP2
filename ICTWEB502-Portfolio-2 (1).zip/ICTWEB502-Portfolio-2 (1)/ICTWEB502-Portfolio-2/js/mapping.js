function initialiseMap() {
    let mapLayer = new L.StamenTileLayer("toner-lite", {
        detectRetina: true

});

    let map = new L.Map("mapid", {
        center: new L.LatLng(28.2282,112.9388),
        zoom: 16
    });

    map.addLayer(mapLayer);
}

initialiseMap();